package com.example.earthquakeapp.model

import android.app.Application
import android.content.ContentValues.TAG
import android.location.Location
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.example.earthquakeapp.R
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.NodeList
import org.xml.sax.SAXException
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.MalformedURLException
import java.net.URL
import java.net.URLConnection
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.GregorianCalendar
import javax.xml.parsers.DocumentBuilder
import javax.xml.parsers.DocumentBuilderFactory
import javax.xml.parsers.ParserConfigurationException

internal class EarthquakeViewModel(application: Application) : AndroidViewModel(application) {
    val mEarthquakes = MutableLiveData<ArrayList<Earthquake>>()
    init {
        viewModelScope.launch {
            loadEarthquakes()
        }
    }

    override fun onCleared() {
        super.onCleared()
        Log.d(TAG, "ViewModel instance about to be destroyed")
    }

    suspend fun loadEarthquakes() : ArrayList<Earthquake?> {
        val earthquakes: ArrayList<Earthquake?> = ArrayList(0)
        val url: URL
        try {
            val quakeFeed: String = getApplication<Application>().resources.getString(R.string.earthquake_feed)
            url = URL(quakeFeed)
            val connection: URLConnection
            connection = withContext(Dispatchers.IO) {
                url.openConnection()
            }
            val httpConnection: HttpURLConnection = connection as HttpURLConnection
            val responseCode: Int =
                withContext(Dispatchers.IO) {
                    httpConnection.getResponseCode()
                }
            if (responseCode == HttpURLConnection.HTTP_OK) {
                val `in`: InputStream =
                    withContext(Dispatchers.IO) {
                        httpConnection.getInputStream()
                    }
                val dbf: DocumentBuilderFactory = DocumentBuilderFactory.newInstance()
                val db: DocumentBuilder = dbf.newDocumentBuilder()
                // Parse the earthquake feed.
                val dom: Document =
                    withContext(Dispatchers.IO) {
                        db.parse(`in`)
                    }
                val docEle: Element = dom.getDocumentElement()
                // Get a list of each earthquake entry.
                val nl: NodeList = docEle.getElementsByTagName("entry")
                if (nl.getLength() > 0) {
                    for (i in 0 until nl.getLength()) {
                        val entry: Element = nl.item(i) as Element
                        val id: Element =
                            entry.getElementsByTagName("id").item(0) as Element
                        val title: Element =
                            entry.getElementsByTagName("title").item(0) as Element
                        val g: Element = entry.getElementsByTagName("georss:point")
                            .item(0) as Element
                        val `when`: Element =
                            entry.getElementsByTagName("updated").item(0) as Element
                        val link: Element =
                            entry.getElementsByTagName("link").item(0) as Element
                        val idString: String = id.getFirstChild().getNodeValue()
                        var details: String = title.getFirstChild().getNodeValue()
                        val hostname = "http://earthquake.usgs.gov"
                        val linkString = hostname + link.getAttribute("href")
                        val point: String = g.getFirstChild().getNodeValue()
                        val dt: String = `when`.getFirstChild().getNodeValue()
                        val sdf = SimpleDateFormat("yyyy-MM-dd'T'hh:mm:ss.SSS'Z'")
                        var qdate: Date = GregorianCalendar(0, 0, 0).getTime()
                        try {
                            qdate = sdf.parse(dt)
                        } catch (e: ParseException) {
                            Log.e(TAG, "Date parsing exception.", e)
                        }
                        val location =
                            point.split(" ".toRegex()).dropLastWhile { it.isEmpty() }
                                .toTypedArray()
                        val l = Location("dummyGPS")
                        l.setLatitude(location[0].toDouble())
                        l.setLongitude(location[1].toDouble())
                        val magnitudeString =
                            details.split(" ".toRegex()).dropLastWhile { it.isEmpty() }
                                .toTypedArray()[1]
                        val end = magnitudeString.length - 1
                        val magnitude = magnitudeString.substring(0, end).toDouble()
                        details = if (details.contains("-")) details.split("-".toRegex())
                            .dropLastWhile { it.isEmpty() }
                            .toTypedArray()[1].trim { it <= ' ' } else ""
                        val earthquake = Earthquake(
                            idString,
                            qdate,
                            details, l,
                            magnitude,
                            linkString
                        )
                        // Add the new earthquake to our result array.
                        earthquakes.add(earthquake)
                    }
                }
            }
            httpConnection.disconnect()
        } catch (e: MalformedURLException) {
            Log.e(TAG, "MalformedURLException", e)
        } catch (e: IOException) {
            Log.e(TAG, "IOException", e)
        } catch (e: ParserConfigurationException) {
            Log.e(TAG, "Parser Configuration Exception", e)
        } catch (e: SAXException) {
            Log.e(TAG, "SAX Exception", e)
        }
        // Return our result array.
        return earthquakes
    }


    fun getEarthquakes(): MutableLiveData<ArrayList<Earthquake>> {
        return mEarthquakes
    }
}