package com.example.earthquakeapp.model

import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.earthquakeapp.databinding.ListItemEarthquakeBinding
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Locale

class EarthquakeRecyclerViewAdapter(private val mEarthquakes: ArrayList<Earthquake?>) : RecyclerView.Adapter<EarthquakeRecyclerViewAdapter.ViewHolder>() {
    private val TIME_FORMAT = SimpleDateFormat("HH:mm", Locale.US)
    private val MAGNITUDE_FORMAT = DecimalFormat("0.0")

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ListItemEarthquakeBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val earthquake = mEarthquakes[position]

        holder.date.text = TIME_FORMAT.format(earthquake?.getDate() ?: 0L)
        holder.details.text = earthquake?.getDetails()
        holder.magnitude.text = earthquake?.let { MAGNITUDE_FORMAT.format(it.getMagnitude()) }

        holder.binding.setEarthquake(earthquake)
        holder.binding.executePendingBindings()
    }

    override fun getItemCount(): Int {
        return mEarthquakes.size
    }

    inner class ViewHolder(val binding: ListItemEarthquakeBinding) : RecyclerView.ViewHolder(binding.root) {
        val date: TextView = binding.date
        val details: TextView = binding.details
        val magnitude: TextView = binding.magnitude

        init {
            binding.timeformat = TIME_FORMAT
            binding.magnitudeformat = MAGNITUDE_FORMAT
        }

        override fun toString(): String {
            return super.toString() + " '" + details.text + "'"
        }
    }
}